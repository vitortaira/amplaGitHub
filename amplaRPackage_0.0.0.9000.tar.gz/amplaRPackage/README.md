
# AmplaGithub

<!-- badges: start -->
<!-- badges: end -->

The goal of AmplaGithub is to ...

## Installation

You can install the development version of AmplaGithub from [GitHub](https://github.com/) with:

``` r
# install.packages("pak")
pak::pak("vitortaira/AmplaGithub")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(AmplaGithub)
## basic example code
```

