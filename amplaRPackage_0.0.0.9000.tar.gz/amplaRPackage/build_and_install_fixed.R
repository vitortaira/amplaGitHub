# =============================================================================
# BUILD E INSTALL COM UNLOAD DO PACOTE amplaRPackage
# =============================================================================

cat("=== BUILD E INSTALAÇÃO amplaRPackage (COM UNLOAD) ===\n")

# 1. Mudar para o diretório do pacote
setwd("c:/Users/Ampla/AMPLA INCORPORADORA LTDA/Controladoria - Documentos/amplaGitHub/amplaRPackage")

# 2. Descarregar o pacote se estiver carregado
cat("1. Descarregando pacote se estiver em uso...\n")
if ("package:amplaRPackage" %in% search()) {
  detach("package:amplaRPackage", unload = TRUE)
  cat("✓ Pacote descarregado\n")
}

# 3. Gerar documentação
cat("2. Gerando documentação...\n")
roxygen2::roxygenise()

# 4. Build do pacote
cat("3. Fazendo build do pacote...\n")
pkg_file <- devtools::build()
cat("Arquivo gerado:", pkg_file, "\n")

# 5. Remover instalação anterior
cat("4. Removendo instalação anterior...\n")
try(remove.packages("amplaRPackage"), silent = TRUE)

# 6. Instalar do arquivo .tar.gz
cat("5. Instalando do arquivo .tar.gz...\n")
install.packages(pkg_file, repos = NULL, type = "source")

# 7. Verificar instalação
cat("6. Verificando instalação...\n")
pkg_installed <- "amplaRPackage" %in% installed.packages()[, "Package"]
cat("Pacote instalado:", pkg_installed, "\n")

if (pkg_installed) {
  cat("✓ Build e instalação bem-sucedidos!\n")
  cat("\nAgora execute:\n")
  cat("library(amplaRPackage)\n")
  cat("?e_metadados\n")
} else {
  cat("✗ Falha na instalação\n")
}
