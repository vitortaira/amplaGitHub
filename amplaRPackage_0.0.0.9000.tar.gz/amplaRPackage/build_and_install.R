# =============================================================================
# BUILD E INSTALL DO PACOTE amplaRPackage
# =============================================================================

cat("=== BUILD E INSTALAÇÃO amplaRPackage ===\n")

# 1. Mudar para o diretório do pacote
setwd("c:/Users/Ampla/AMPLA INCORPORADORA LTDA/Controladoria - Documentos/amplaGitHub/amplaRPackage")

# 2. Gerar documentação
cat("1. Gerando documentação...\n")
roxygen2::roxygenise()

# 3. Build do pacote
cat("2. Fazendo build do pacote...\n")
pkg_file <- devtools::build()
cat("Arquivo gerado:", pkg_file, "\n")

# 4. Remover instalação anterior
cat("3. Removendo instalação anterior...\n")
try(remove.packages("amplaRPackage"), silent = TRUE)

# 5. Instalar do arquivo .tar.gz
cat("4. Instalando do arquivo .tar.gz...\n")
install.packages(pkg_file, repos = NULL, type = "source")

# 6. Verificar instalação
cat("5. Verificando instalação...\n")
pkg_installed <- "amplaRPackage" %in% installed.packages()[, "Package"]
cat("Pacote instalado:", pkg_installed, "\n")

if (pkg_installed) {
  cat("✓ Build e instalação bem-sucedidos!\n")
  cat("\nAgora execute:\n")
  cat("library(amplaRPackage)\n")
  cat("?e_metadados\n")
} else {
  cat("✗ Falha na instalação\n")
}
