# =============================================================================
# TESTE DE DOCUMENTAÇÃO DO PACOTE amplaRPackage
# =============================================================================

cat("=== TESTANDO DOCUMENTAÇÃO ===\n\n")

# 1. Verificar se o pacote está instalado
cat("1. Verificando instalação...\n")
pkg_installed <- "amplaRPackage" %in% installed.packages()[, "Package"]
cat("Pacote instalado:", pkg_installed, "\n")

if (!pkg_installed) {
  cat("ERRO: Pacote não está instalado. Execute fix_documentation.R primeiro.\n")
  stop("Pacote não instalado")
}

# 2. Carregar o pacote
cat("2. Carregando pacote...\n")
library(amplaRPackage)

# 3. Verificar se a função existe
cat("3. Verificando se a função existe...\n")
func_exists <- exists("e_metadados")
cat("Função e_metadados existe:", func_exists, "\n")

# 4. Testar diferentes formas de acessar a documentação
cat("4. Testando acesso à documentação...\n")

cat("Tentando help()...\n")
try({
  help("e_metadados", package = "amplaRPackage")
  cat("✓ help() funcionou\n")
}, silent = TRUE)

cat("Tentando ?e_metadados...\n")
try({
  ?e_metadados
  cat("✓ ?e_metadados funcionou\n")
}, silent = TRUE)

cat("Tentando utils::help()...\n")
try({
  utils::help("e_metadados", package = "amplaRPackage")
  cat("✓ utils::help() funcionou\n")
}, silent = TRUE)

cat("\n=== TESTE CONCLUÍDO ===\n")
cat("Se algum método funcionou, a documentação está disponível.\n")
cat("Se nenhum funcionou, pode ser necessário reiniciar o R.\n")
