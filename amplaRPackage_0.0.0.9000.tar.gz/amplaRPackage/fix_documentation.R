# =============================================================================
# SCRIPT PARA RESOLVER PROBLEMA DE DOCUMENTAÇÃO DO PACOTE amplaRPackage
# =============================================================================

cat("=== INSTALANDO E CONFIGURANDO PACOTE amplaRPackage ===\n\n")

# 1. Instalar/carregar pacotes necessários
cat("1. Instalando pacotes necessários...\n")
if (!require(roxygen2, quietly = TRUE)) install.packages("roxygen2")
if (!require(devtools, quietly = TRUE)) install.packages("devtools")

# 2. Definir diretório do pacote
cat("2. Definindo diretório do pacote...\n")
setwd("c:/Users/Ampla/AMPLA INCORPORADORA LTDA/Controladoria - Documentos/amplaGitHub/amplaRPackage")

# 3. Gerar documentação com roxygen2
cat("3. Gerando documentação...\n")
roxygen2::roxygenise()

# 4. Remover instalação anterior (se existir)
cat("4. Removendo instalação anterior...\n")
try(remove.packages("amplaRPackage"), silent = TRUE)

# 5. Instalar o pacote
cat("5. Instalando pacote...\n")
devtools::install(quiet = TRUE, dependencies = FALSE)

cat("\n=== CONFIGURAÇÃO CONCLUÍDA ===\n")
cat("Agora execute os seguintes comandos:\n")
cat("library(amplaRPackage)\n")
cat("?e_metadados\n")
cat("\nSe ainda não funcionar, reinicie o R e execute:\n")
cat("library(amplaRPackage)\n")
cat("help('e_metadados', package = 'amplaRPackage')\n")
