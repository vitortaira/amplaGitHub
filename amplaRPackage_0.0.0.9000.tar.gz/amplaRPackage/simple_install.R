# =============================================================================
# INSTALAÇÃO SIMPLES DO PACOTE amplaRPackage
# =============================================================================

cat("=== INSTALANDO amplaRPackage ===\n")

# 1. Mudar para o diretório do pacote
setwd("c:/Users/Ampla/AMPLA INCORPORADORA LTDA/Controladoria - Documentos/amplaGitHub/amplaRPackage")

# 2. Gerar documentação
cat("Gerando documentação...\n")
roxygen2::roxygenise()

# 3. Remover instalação anterior
cat("Removendo instalação anterior...\n")
try(remove.packages("amplaRPackage"), silent = TRUE)

# 4. Instalar usando método simples
cat("Instalando pacote...\n")
devtools::install()

# 5. Verificar instalação
cat("Verificando instalação...\n")
pkg_installed <- "amplaRPackage" %in% installed.packages()[, "Package"]
cat("Pacote instalado:", pkg_installed, "\n")

if (pkg_installed) {
  cat("✓ Instalação bem-sucedida!\n")
  cat("\nAgora execute:\n")
  cat("library(amplaRPackage)\n")
  cat("?e_metadados\n")
} else {
  cat("✗ Falha na instalação\n")
}
